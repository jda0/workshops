# arduino-sketch-hedgehog-bot-wifi
An Arduino sketch for the HedgeHog bot that demonstrates how to use [Blynk](http://www.blynk.cc/) to remotely control your bot.
