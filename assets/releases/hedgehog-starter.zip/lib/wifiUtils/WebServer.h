#ifndef _WEBSERVER_H
#define _WEBSERVER_H
#include "Arduino.h"

String getWebPageHtml();

#endif

