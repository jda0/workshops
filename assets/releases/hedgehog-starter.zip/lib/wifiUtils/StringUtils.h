#ifndef _STRINGUTILS_H
#define _STRINGUTILS_H
#include "Arduino.h"

boolean contains(String haystack, String needle);

#endif
