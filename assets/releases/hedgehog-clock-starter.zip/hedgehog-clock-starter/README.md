# ![Hedgehog Clock](https://raw.githubusercontent.com/jda0/hedgehog/gh-pages/assets/hedgehog_clock-vert-light.svg?sanitize=true)

# Starter package

- **Now compatible with Arduino IDE! Just open `src/src.ino`**

- `src/hh_clock.cpp` contains a lot of TODOs for workshop partipants to do, with lots of comments to help.
    - I hope this can be extended to `src/hh_server.cpp` and some of the libs

## Contributing

- Please commit any changes made to the code you derive this starter from to `master` as the parent commit to your changes to this branch.
- Please submit PRs!
